from typing import Callable, Literal
import numpy.typing as npt
import matplotlib.pyplot as plt
import numpy as np

def backtrack(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    x: npt.NDArray[np.float64],
    grad: npt.NDArray[np.float64],
    constraint_type,
    constraints
) :
    beta = 0.9
    t = 1
    a = 0.001
    proj = projection(x - t * grad, constraint_type, constraints)
    diff = np.linalg.norm(proj - x)
    while f(x) - f(proj) < a * (diff**2/t):
        t = beta * t
        proj = projection(x - t * grad, constraint_type, constraints)
        diff = np.linalg.norm(proj - x)
    return t
def projection(x,constraint_type, constraints) :
    if constraint_type == "linear":
        lb, ub = constraints
        y=x.copy()
        n=y.size
        for i in range(n):
            if y[i]>ub[i]:
                t1= ub[i]
            elif y[i]<lb[i]:
                t1=lb[i]
            else:
                t1=y[i]
            y[i]=t1
        return y
    else:
        c, r = constraints
        diff = x - c
        denom = max(np.linalg.norm(diff),r)
        return ((diff*r)/denom) + c
def projected_gd(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    point: npt.NDArray[np.float64],
    constraint_type: Literal["linear", "l_2"],
    constraints: npt.NDArray[np.float64] | tuple[npt.NDArray[np.float64], np.float64],
   
) -> npt.NDArray[np.float64]:
    
    x = point
    i=0
    while i < 1000:
        grad = d_f(x)
        t = backtrack(f, d_f, x, grad, constraint_type, constraints)
        next = projection(x - t * grad, constraint_type, constraints)
        diff=np.linalg.norm(next - x)
        x = next
        if diff< 1e-6:
            break
        i+=1
    return x
    
def dual_ascent(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    c: list[Callable[[npt.NDArray[np.float64]], np.float64 | float]],
    d_c: list[Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]]],
    initial_point: npt.NDArray[np.float64],
) -> npt.NDArray[np.float64]:
    
    a = 1e-3
    x = initial_point.copy()
    m = len(c)
    ind =0
    lambdaVal = np.ones(m)
    while ind< 100000:
        gradx = d_f(x)
        i=0
        while i<m:
            gradx += lambdaVal[i] * d_c[i](x)
            i+=1
        gradLambda = np.zeros(m)

        xNext = x - a* gradx

        i=0
        while i<m:
            gradLambda[i] = c[i](xNext)
            i+=1

        lambdaNext = np.maximum(lambdaVal+ a * gradLambda,0)

        x= xNext
        lambdaVal = lambdaNext
        ind+=1 
    return (x, lambdaVal)
