from typing import Callable, Literal

from numpy.typing import NDArray
import matplotlib.pyplot as plt
import numpy as np



def fxplot(op, initial_point,f,approach):
    plt.plot(range(len(op)), op)
    plt.xlabel("No of Iterations")
    plt.ylabel("f(x)")
    plt.title(f"{f.__name__}_{np.array2string(initial_point)}_{approach}_vals")
    plt.savefig(f"plots/{f.__name__}_{np.array2string(initial_point)}_{approach}_vals.png")
    # plt.show()
    
def gradplot(gradVal,initial_point,f,approach):
    plt.plot(range(len(gradVal)), gradVal)
    plt.xlabel("No of Iterations")
    plt.ylabel("|f'(x)|")
    plt.title(f"{f.__name__}_{np.array2string(initial_point)}_{approach}_grad")
    plt.savefig(f"plots/{f.__name__}_{np.array2string(initial_point)}_{approach}_grad.png")
    # plt.show()
    
def contourPloting(f,x,inp,initial_point,l1,l2,r1,r2,approach):
    x_vals = np.linspace(l1- 1, r1+1, 100)
    y_vals = np.linspace(l2 - 1,  r2+1, 100)
    X, Y = np.meshgrid(x_vals, y_vals)
    for i in range(len(inp)):
        plt.scatter(inp[i][0], inp[i][1], color='red', marker='|')
        if i > 0:
            plt.arrow(inp[i-1][0], inp[i-1][1], inp[i][0] - inp[i-1][0], inp[i][1] - inp[i-1][1], color='blue', head_width=0.01)
       
    points = np.vstack([X.ravel(), Y.ravel()]).T
    results = np.apply_along_axis(f, 1, points)
    Z = results.reshape(X.shape)

    plt.contour(X, Y, Z, levels=20)
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.title(f"{f.__name__}_{np.array2string(initial_point)}_{approach}_cont")
    plt.legend()
    plt.savefig(f"plots/{f.__name__}_{np.array2string(initial_point)}_{approach}_cont.png")
    # plt.show()


def conjugate_descent(
    initial_point: NDArray[np.float64],
    f: Callable[[NDArray[np.float64]], np.float64|float],
    d_f: Callable[[NDArray[np.float64]], NDArray[np.float64]],
    approach: Literal["Hestenes-Stiefel", "Polak-Ribiere", "Fletcher-Reeves"],
) -> NDArray[np.float64]:
    
    x = initial_point
    szip=len(x)
    eps=1e-6
    
    inp=[]
    op = []
    gradVal = []

    
    op.append(f(x))
    inp.append(x)
    gradVal.append(np.linalg.norm(d_f(x)))
    
    prevGrad=d_f(x)
    d=-prevGrad
    step=0
    for i in range(10000):
        if np.linalg.norm(prevGrad) < eps:
            break
            
        c1=0.001
        c2=0.1
        alpha=0
        beta=1000000
        k=0
        t=1
        while k<1000:
            upgrad= d_f(x + t * d)
            if f(x + t * d) > f(x) + c1 * t * np.dot(prevGrad, d):
                beta = t
                t = 0.5 * (alpha + beta)
            elif np.dot(d, upgrad) < c2 * np.dot(prevGrad, d):
                alpha = t
                t = 0.5 * (alpha + beta)
            else:
                break
            k+=1
        x = x + t * d
        newGrad=d_f(x)
        
        if approach == "Hestenes-Stiefel" and step< szip-1:
            beta = np.dot(newGrad, newGrad - prevGrad) / np.dot(d, newGrad - prevGrad)
            d = -newGrad+ beta * d 
            step+=1
        elif approach == "Polak-Ribiere" and step< szip-1:
            beta =  np.dot(newGrad, newGrad- prevGrad) / np.linalg.norm(prevGrad)**2
            d = -newGrad+ beta * d 
            step+=1
        elif approach == "Fletcher-Reeves" and step< szip-1:
            beta = np.dot(newGrad, newGrad) / np.dot(prevGrad, prevGrad)
            d = -newGrad+ beta * d 
            step+=1
        else:
            step=0
            d=-newGrad            
           
        prevGrad=newGrad
        op.append(f(x))
        inp.append(x)
        gradVal.append(np.linalg.norm(d_f(x)))
       
    fxplot(op, initial_point,f,approach)
    gradplot(gradVal,initial_point,f,approach)
    l1=x[0] 
    l2=x[1]
    r1=x[0]
    r2=x[1]

    for i in range(len(inp)):
        l1=min(l1,inp[i][0])
        l2=min(l2,inp[i][1])
        r1=max(r1,inp[i][0])
        r2=max(r2,inp[i][1]);
    if szip< 3:
        contourPloting(f,x,inp,initial_point,l1,l2,r1,r2,approach)

    return x

def sr1(
    initial_point: NDArray[np.float64],
    f: Callable[[NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[NDArray[np.float64]], NDArray[np.float64]],
    
) -> NDArray[np.float64]:

    eps = 1e-6,
    approach="sr1"
    x = initial_point
    szip=len(x)
   
    
    inp=[]
    op = []
    gradVal = []
    # B= np.eye(len(initial_point))  
    B = np.diag(np.arange(1, szip + 1))


    
    for i in range(10000):
        grad = d_f(x)
        inp.append(x)
        op.append(f(x))
        gradVal.append(np.linalg.norm(grad))
        if np.linalg.norm(grad) < eps:
            break
        else:
            p = -np.dot(B, grad) 
        c1=0.001
        c2=0.1
        alpha=0
        beta=1000000
        k=0
        t=1
        while k<1000:
            upgrad= d_f(x + t * p)
            if f(x + t * p)> f(x) + c1*t * np.dot(grad,p):
                beta = t
                t = 0.5*(alpha +beta)
            elif np.dot(p,upgrad) < c2*np.dot(grad,p):
                alpha = t
                t = 0.5*(alpha + beta)
            else:
                break
            k+=1
        s=t*p       
        y = d_f(x+s)-grad
        B= B+ np.outer(s-np.dot(B, y),s-np.dot(B, y))/np.dot(s-np.dot(B, y), y)
        x =x+ s
       
    fxplot(op, initial_point,f,approach)
    gradplot(gradVal,initial_point,f,approach)
    l1=x[0] 
    l2=x[1]
    r1=x[0]
    r2=x[1]
    for i in range(len(inp)):
        l1=min(l1,inp[i][0])
        l2=min(l2,inp[i][1])
        r1=max(r1,inp[i][0])
        r2=max(r2,inp[i][1]);
    if szip< 3:
        contourPloting(f,x,inp,initial_point,l1,l2,r1,r2,approach)
    return x


def dfp(
    initial_point: NDArray[np.float64],
    f: Callable[[NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[NDArray[np.float64]], NDArray[np.float64]],
) -> NDArray[np.float64]:
    
    x = initial_point
    szip = len(x)
    eps = 1e-6,
    
    
    approach="dfp"
    op = []
    gradVal = []
    inp =[]
    # B = np.eye(len(initial_point)) 
    B = np.diag(np.arange(1, szip + 1))
    for i in range(10000):
        grad = d_f(x)
        
        inp.append(x)
        op.append(f(x))
        gradVal.append(np.linalg.norm(grad))
        
        if np.linalg.norm(grad) < eps:
            break
        else:
            p = -np.dot(B, grad) 
        
        c1=0.001
        c2=0.1
        alpha=0
        beta=1000000
        k=0
        t=1
        while k<1000:
            upgrad= d_f(x + t * p)
            if f(x + t * p) > f(x) + c1 * t * np.dot(grad, p):
                beta = t
                t = 0.5 * (alpha + beta)
            elif np.dot(p, upgrad) < c2 * np.dot(grad, p):
                alpha = t
                t = 0.5 * (alpha + beta)
            else:
                break
            k+=1
        
        s = t * p
        y = d_f(x+s) - grad
        B = B+np.outer(s, s) / np.dot(s, y) - np.outer(np.dot(B, y), np.dot(B, y)) / np.dot(np.dot(B, y),y)
        x = x+s
    fxplot(op, initial_point,f,approach)
    gradplot(gradVal,initial_point,f,approach)
    l1=x[0] 
    l2=x[1]
    r1=x[0]
    r2=x[1]

    for i in range(len(inp)):
        l1=min(l1,inp[i][0])
        l2=min(l2,inp[i][1])
        r1=max(r1,inp[i][0])
        r2=max(r2,inp[i][1]);
    if szip< 3:
        contourPloting(f,x,inp,initial_point,l1,l2,r1,r2,approach)
    

    return x



def bfgs(
    initial_point: NDArray[np.float64],
    f: Callable[[NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[NDArray[np.float64]], NDArray[np.float64]],
) -> NDArray[np.float64]:
    
    x = initial_point
    szip=len(x)
    eps = 1e-6,
      
    
    approach="bfgs"
    inp=[]
    op = []
    gradVal = []
    # B = np.eye(len(initial_point))
    B = np.diag(np.arange(1, szip + 1))

    for i in range(10000):
        grad = d_f(x)
        
        inp.append(x)
        op.append(f(x))
        gradVal.append(np.linalg.norm(grad))
        
        if np.linalg.norm(grad) < eps:
            break
        else:
            p = -np.dot(B, grad)  # Compute the search direction
        
        # Line search
        c1=0.001
        c2=0.1
        alpha=0
        beta=1000000
        k=0
        t=1
        while k<1000:
            upgrad= d_f(x + t * p)
            if f(x + t * p) > f(x) + c1 * t * np.dot(grad, p):
                beta = t
                t = 0.5 * (alpha + beta)
            elif np.dot(p, upgrad) < c2 * np.dot(grad, p):
                alpha = t
                t = 0.5 * (alpha + beta)
            else:
                break
            k+=1
        
        s = t * p
        y = d_f(x+s) - grad
        rho = 1 / np.dot(y, s)
        B = (np.eye(len(x)) - rho * np.outer(s, y)) @ B @ (np.eye(len(x)) - rho * np.outer(y, s)) + rho * np.outer(s, s)
        x =x+ s
    fxplot(op, initial_point,f,approach)
    gradplot(gradVal,initial_point,f,approach)
    l1=x[0] 
    l2=x[1]
    r1=x[0]
    r2=x[1]
    for i in range(len(inp)):
        l1=min(l1,inp[i][0])
        l2=min(l2,inp[i][1])
        r1=max(r1,inp[i][0])
        r2=max(r2,inp[i][1]);
    if szip< 3:
        contourPloting(f,x,inp,initial_point,l1,l2,r1,r2,approach)
    

    return x

