from typing import Callable, Literal

import matplotlib.pyplot as plt
import numpy as np
import numpy.typing as npt


def fxplot(op, initial_point,condition,f):
    plt.plot(range(len(op)), op)
    plt.xlabel("No of Iterations")
    plt.ylabel("f(x)")
    plt.title(f"{f.__name__}_{np.array2string(initial_point)}_{condition}_vals")
    plt.savefig(f"plots/{f.__name__}_{np.array2string(initial_point)}_{condition}_vals.png")
    plt.show()
    
def gradplot(gradVal,initial_point,condition,f):
    plt.plot(range(len(gradVal)), gradVal)
    plt.xlabel("No of Iterations")
    plt.ylabel("|f'(x)|")
    plt.title(f"{f.__name__}_{np.array2string(initial_point)}_{condition}_grad")
    plt.savefig(f"plots/{f.__name__}_{np.array2string(initial_point)}_{condition}_grad.png")
    plt.show()
    
def contourPloting(f,x,inp,initial_point,condition,l1,l2,r1,r2):
    x_vals = np.linspace(l1- 1, r1+1, 100)
    y_vals = np.linspace(l2 - 1,  r2+1, 100)
    X, Y = np.meshgrid(x_vals, y_vals)
    for i in range(len(inp)):
        plt.scatter(inp[i][0], inp[i][1], color='red', marker='|')
        if i > 0:
            plt.arrow(inp[i-1][0], inp[i-1][1], inp[i][0] - inp[i-1][0], inp[i][1] - inp[i-1][1], color='blue', head_width=0.01)
       
    points = np.vstack([X.ravel(), Y.ravel()]).T
    results = np.apply_along_axis(f, 1, points)
    Z = results.reshape(X.shape)

    plt.contour(X, Y, Z, levels=20)
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.title(f"{f.__name__}_{np.array2string(initial_point)}_{condition}_cont")
    plt.legend()
    plt.savefig(f"plots/{f.__name__}_{np.array2string(initial_point)}_{condition}_cont.png")
    plt.show()
    


def steepest_descent(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    condition: Literal["Backtracking", "Bisection"],
) -> npt.NDArray[np.float64]:
    
    alpha0 = 10.0
    p = 0.75
    c = 0.001
    min_grad = 1e-6
    x = initial_point
    szip=len(x)
    maxIteration = 10000
    op = []
    inp=[]
    inp.append(x)
    op.append(f(x))
    gradVal = []
    for i in range(maxIteration):
        if condition == "Backtracking":
            alpha = alpha0
            grad = d_f(x)
            if np.linalg.norm(grad) < min_grad:
                print("Finally , Converged after", i, "steps")
                break
            else:
                dk = -grad
            while f(x + alpha * dk) > f(x) + c * alpha * np.dot(grad, dk):
                alpha *= p
            t = alpha  
            x = x + t * dk
            op.append(f(x))
            gradVal.append(np.linalg.norm(grad))
            inp.append(x)


        elif condition == "Bisection":
            alpha = 0.0
            beta = 1e6
            c1 = 0.001
            c2 = 0.1
            t=1;
            grad = d_f(x)
            if np.linalg.norm(grad) < min_grad:
                print("Finally , Converged after", i, "steps")
                break
            else:
                dk = -grad
            while beta - alpha > min_grad:
                upgrad= d_f(x + t * dk)
                if f(x + t * dk) > f(x) + c1 * t * np.dot(grad, dk):
                    beta = t
                    t = 0.5 * (alpha + beta)
                elif np.dot(dk, upgrad) < c2 * np.dot(grad, dk):
                    alpha = t
                    t = 0.5 * (alpha + beta)
                else:
                    break
            x = x + t * dk
            op.append(f(x))
            gradVal.append(np.linalg.norm(grad))
            inp.append(x)
    l1=x[0] 
    l2=x[1]
    r1=x[0]
    r2=x[1]

    for i in range(len(inp)):
        l1=min(l1,inp[i][0])
        l2=min(l2,inp[i][1])
        r1=max(r1,inp[i][0])
        r2=max(r2,inp[i][1]);
    fxplot(op,initial_point,condition,f)
    gradplot(gradVal,initial_point,condition,f)
    if szip< 3:
        contourPloting(f,x,inp,initial_point,condition,l1,l2,r1,r2)
    return x

def newton_method(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    d2_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    condition: Literal["Pure", "Damped", "Levenberg-Marquardt", "Combined"],
    
) -> npt.NDArray[np.float64]:
    
    min_grad = 1e-6
    x = initial_point
    szip=len(x)
    maxIteration = 10000
    op = []
    inp=[]
    inp.append(x)
    op.append(f(x))
    gradVal = []

    for i in range(maxIteration):
        if condition == "Pure":
            grad = d_f(x)
            hess = d2_f(x)
            if np.linalg.norm(grad) <= min_grad:
                print(f"Finally Converged after {i} iterations")
                break
            else:
                x = x - np.linalg.solve(hess, grad)
            inp.append(x)
            op.append(f(x))
            gradVal.append(np.linalg.norm(grad))
                
        elif condition == "Damped":
            alpha = 0.001
            beta=0.75
            grad = d_f(x)
            hess = d2_f(x)
            d=np.linalg.solve(hess, grad)
            tk=1
            if np.linalg.norm(grad) <= min_grad:
                print(f"Finally converged after {i} iterations")
                break
            while f(x)-f(x + tk * d) < -1* tk * alpha * np.dot(grad,d):
                tk =tk* beta
            x = x+tk*d
            inp.append(x)
            op.append(f(x))
            gradVal.append(np.linalg.norm(grad))
        elif condition == "Levenberg-Marquardt":
            grad = d_f(x)
            hess = d2_f(x)
            mineigenval = np.min(np.linalg.eigvals(hess))
            if np.linalg.norm(grad) <= min_grad:
                print(f"Finally , Converged after {i} iterations")
                break
            elif mineigenval <= 0:
                uk = -mineigenval + 0.1
                step = -np.linalg.solve(hess + uk * np.eye(len(x)), grad)
                x = x + step
            else:
                step = -np.linalg.solve(hess ,grad)
                x = x + step
            inp.append(x)
            op.append(f(x))
            gradVal.append(np.linalg.norm(grad))
        elif condition == "Combined":
            grad = d_f(x)
            hess = d2_f(x)
            mineigenval = np.min(np.linalg.eigvals(hess))
            if np.linalg.norm(grad) <= min_grad:
                print(f"Finally Converged after {i} iterations")
                break
            elif mineigenval <= 0:
                up= (-mineigenval + 0.1)
                step = -np.linalg.solve(hess + up * np.eye(len(x)), grad)
                x = x + step
            else:
                step = -np.linalg.solve(hess , grad)
                x = x + step

            alpha = 1.0
            while f(x + alpha * step)-f(x)  >  0.001 * alpha * np.dot(grad, step):
                alpha *= 0.5

            x = x + alpha * step
            inp.append(x)
            op.append(f(x))
            gradVal.append(np.linalg.norm(grad))
       

    
    l1=x[0] 
    l2=x[1]
    r1=x[0]
    r2=x[1]

    for i in range(len(inp)):
        l1=min(l1,inp[i][0])
        l2=min(l2,inp[i][1])
        r1=max(r1,inp[i][0])
        r2=max(r2,inp[i][1])

    
    fxplot(op,initial_point,condition,f)
    gradplot(gradVal,initial_point,condition,f)
    if szip<3:
        contourPloting(f,x,inp,initial_point,condition,l1,l2,r1,r2)

    return x
